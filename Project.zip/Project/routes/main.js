//var Round = require("../models/Round");


module.exports = function(app, obj, randomString) {
    app.get("/", async function(req, res, next) {
        return res.render('home/index', {
            'title': 'SaiGon ICT Tennis club',
            "page":"home"
        });
    });

    app.get("/teams", async function(req, res, next) {
        return res.render('home/index', {
            'title': 'SaiGon ICT Tennis club',
            "page":"players"
        });
    });
}
