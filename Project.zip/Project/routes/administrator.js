var Book = require("../models/Book");


module.exports = function(app, obj, randomString) {
    app.get("/administrator", async function(req, res, next) {
        return res.render('administrator/home', {
            'title': 'SaiGon ICT Tennis club',
            "page":"home"
        });
    });

    app.post("/administrator/book/addNew", function(req, res){
        if (!req.body.title || !req.body.image || !req.body.content || !req.body.categories){
            res.json({result:0, message:"Lack of parameter"});
        }else{
            var title       = req.body.title
            var image       = req.body.image
            var content     = req.body.content
            var categories  = req.body.categories
            var views       = 0
            var rate        = 0

            // Create new book
            var newBook = new Book({
                title       : title,
                image       : image,
                content     : content,
                categories  : categories,
                views       : views,
                rate        : rate
            });

            newBook.save()
            .then((Book)=>{
                res.json({result:1, message:"Create new book successfully.", list: Book});
            })
            .catch((SaveError)=>{
                res.json({result:0, message:"Saving error!!!" + SaveError});
            })
        }
    });
}
