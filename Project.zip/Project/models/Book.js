var mongoose = require("mongoose");
const bookSchema = new mongoose.Schema({
    title       : String,
    image       : String,
    content     : String,
    categories  : String,
    views       : Number,
    rate        : Number
});
module.exports = mongoose.model("Book", bookSchema);